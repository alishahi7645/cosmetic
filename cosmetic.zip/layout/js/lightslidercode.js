$("#lightSlider").lightSlider({
  // rtl:false,
  // item: 5,
  // slideMargin: 10,
  // loop: false,
  // pager: true,
  // auto: false,
  // pause: 3000,
  // enableTouch: false,
  // enableDrag: false,
  // keyPress: false,
  // controls: true,
  // prevHtml: '',
  // nextHtml: '',
  // thumbItem:10,
  item: 5,

  slideMargin: 10,



  speed: 400, //ms'
  auto: false,
  loop: false,
  slideEndAnimation: true,
  pause: 2000,

  keyPress: true,
  controls: true,
  prevHtml: "",
  nextHtml: "",

  rtl: true,
  adaptiveHeight: false,

  vertical: false,
  verticalHeight: 500,
  vThumbWidth: 100,

  thumbItem: 10,
  pager: true,
  gallery: false,
  galleryMargin: 5,
  thumbMargin: 5,
  currentPagerPosition: "middle",

  enableTouch: true,
  enableDrag: true,
  freeMove: true,
  swipeThreshold: 40,

  onBeforeStart: function (el) {},
  onSliderLoad: function (el) {},
  onBeforeSlide: function (el) {},
  onAfterSlide: function (el) {},
  onBeforeNextSlide: function (el) {},
  onBeforePrevSlide: function (el) {},
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        item: 3,
        slideMargin: 7,
      },
    },
    {
      breakpoint: 768,
      settings: {
        item: 2,
        slideMargin: 7,
      },
    },
    {
      breakpoint: 576,
      settings: {
        item: 1,
      },
    },
    {
      breakpoint: 400,
      settings: {
        item: 1,
      },
    },
  ],
});
$("#lightSlider1").lightSlider({
  // rtl:false,
  // item: 5,
  // slideMargin: 10,
  // loop: false,
  // pager: true,
  // auto: false,
  // pause: 3000,
  // enableTouch: false,
  // enableDrag: false,
  // keyPress: false,
  // controls: true,
  // prevHtml: '',
  // nextHtml: '',
  // thumbItem:10,
  item: 5,

  slideMargin: 10,



  speed: 400, //ms'
  auto: false,
  loop: false,
  slideEndAnimation: true,
  pause: 2000,

  keyPress: true,
  controls: true,
  prevHtml: "",
  nextHtml: "",

  rtl: true,
  adaptiveHeight: false,

  vertical: false,
  verticalHeight: 500,
  vThumbWidth: 100,

  thumbItem: 10,
  pager: true,
  gallery: false,
  galleryMargin: 5,
  thumbMargin: 5,
  currentPagerPosition: "middle",

  enableTouch: true,
  enableDrag: true,
  freeMove: true,
  swipeThreshold: 40,

  onBeforeStart: function (el) {},
  onSliderLoad: function (el) {},
  onBeforeSlide: function (el) {},
  onAfterSlide: function (el) {},
  onBeforeNextSlide: function (el) {},
  onBeforePrevSlide: function (el) {},
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        item: 3,
        slideMargin: 7,
      },
    },
    {
      breakpoint: 768,
      settings: {
        item: 2,
        slideMargin: 7,
      },
    },
    {
      breakpoint: 576,
      settings: {
        item: 1,
      },
    },
    {
      breakpoint: 400,
      settings: {
        item: 1,
      },
    },
  ],
});
$("#lightSlider2").lightSlider({
  // rtl:false,
  // item: 5,
  // slideMargin: 10,
  // loop: false,
  // pager: true,
  // auto: false,
  // pause: 3000,
  // enableTouch: false,
  // enableDrag: false,
  // keyPress: false,
  // controls: true,
  // prevHtml: '',
  // nextHtml: '',
  // thumbItem:10,
  item: 4,

  slideMargin: 10,



  speed: 400, //ms'
  auto: false,
  loop: false,
  slideEndAnimation: true,
  pause: 2000,

  keyPress: true,
  controls: true,
  prevHtml: "",
  nextHtml: "",

  rtl: true,
  adaptiveHeight: false,

  vertical: false,
  verticalHeight: 500,
  vThumbWidth: 100,

  thumbItem: 10,
  pager: true,
  gallery: false,
  galleryMargin: 5,
  thumbMargin: 5,
  currentPagerPosition: "middle",

  enableTouch: true,
  enableDrag: true,
  freeMove: true,
  swipeThreshold: 40,

  onBeforeStart: function (el) {},
  onSliderLoad: function (el) {},
  onBeforeSlide: function (el) {},
  onAfterSlide: function (el) {},
  onBeforeNextSlide: function (el) {},
  onBeforePrevSlide: function (el) {},
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        item: 3,
        slideMargin: 7,
      },
    },
    {
      breakpoint: 768,
      settings: {
        item: 2,
        slideMargin: 7,
      },
    },
    {
      breakpoint: 576,
      settings: {
        item: 1,
      },
    },
    {
      breakpoint: 400,
      settings: {
        item: 1,
      },
    },
  ],
});
